package com.ofss;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
	// Define 3 methods
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
		httpSecurity.authorizeHttpRequests(
		auth -> auth.requestMatchers("/admin/**").hasRole("ADMIN") // pratham, subham, sreenath
		.requestMatchers("/user").hasAnyRole("USER") // guru, sreenath
		.anyRequest().authenticated()) // anybody can access 
		.formLogin(form -> form.permitAll())
		.logout(lg->lg.permitAll());
		return httpSecurity.build();
		
	}
	
	@Bean
	public UserDetailsService userDetailService() {
		// takes the responsibility of providing the existing username/password
		// may be in-memory or from DB server
		// This method, we need to define the roles
		UserDetails ud1=User.builder().username("pratham").password(passwordEncoder().encode("pratham123")).roles("ADMIN").build();
		UserDetails ud2=User.builder().username("guru").password(passwordEncoder().encode("guru123")).roles("USER").build();
		UserDetails ud3=User.builder().username("shubam").password(passwordEncoder().encode("shubam123")).roles("ADMIN").build();
		UserDetails ud4=User.builder().username("sreenath").password(passwordEncoder().encode("sreenath123")).roles("ADMIN","USER").build();
		return new InMemoryUserDetailsManager(ud1,ud2,ud3,ud4);
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
